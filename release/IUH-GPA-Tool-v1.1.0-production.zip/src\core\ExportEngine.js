(function (global) {
  'use strict';

  const EXPORT_DISCLAIMER = 'MÔ PHỎNG – KHÔNG PHẢI BẢNG ĐIỂM CHÍNH THỨC IUH';

/**
 * Các ký tự kích hoạt thực thi công thức trong bảng tính (Excel, LibreOffice, Google Sheets)
 */
const FORMULA_TRIGGERS = ['=', '+', '-', '@', '\t', '\r'];

/**
 * Sanitize một ô văn bản nhằm ngăn chặn CSV / Spreadsheet Formula Injection.
 * Nếu chuỗi bắt đầu bằng các ký tự trigger công thức (=, +, -, @, \t, \r),
 * thêm dấu nháy đơn ' ở đầu để buộc bảng tính hiểu đây là kiểu TEXT thuần túy.
 *
 * @param {*} value
 * @returns {string}
 */
function sanitizeSpreadsheetCell(value) {
  if (value === null || value === undefined) {
    return '';
  }

  // Nếu là số thực sự thì giữ nguyên định dạng số
  if (typeof value === 'number') {
    return Number.isFinite(value) ? String(value) : '';
  }

  if (typeof value === 'boolean') {
    return value ? 'ĐẠT' : 'RỚT';
  }

  let str = String(value);

  // Loại bỏ control characters độc hại ở đầu (ngoại trừ ký tự có thể in)
  // Nếu ký tự đầu tiên nằm trong danh sách trigger
  if (str.length > 0 && FORMULA_TRIGGERS.includes(str[0])) {
    // Prefix bằng dấu nháy đơn theo chuẩn bảo mật bảng tính OWASP
    str = "'" + str;
  }

  return str;
}

/**
 * Escape một ô CSV theo chuẩn RFC 4180
 * Bao bọc bởi ngoặc kép nếu chứa dấu phẩy, ngoặc kép hoặc ký tự xuống dòng.
 * Dấu ngoặc kép bên trong được nhân đôi (" -> "").
 *
 * @param {*} rawValue
 * @returns {string}
 */
function escapeCSVField(rawValue) {
  const sanitized = sanitizeSpreadsheetCell(rawValue);

  // Nếu chuỗi chứa dấu phẩy, ngoặc kép, hoặc xuống dòng thì phải bọc ngoặc kép
  if (sanitized.includes('"') || sanitized.includes(',') || sanitized.includes('\n') || sanitized.includes('\r')) {
    return `"${sanitized.replace(/"/g, '""')}"`;
  }

  return sanitized;
}

/**
 * Tạo tên file xuất an toàn, ngăn chặn Directory Traversal và ký tự đặc biệt của OS
 *
 * @param {string} [prefix='IUH-GPA-Mo-Phong']
 * @param {string} [extension='csv']
 * @param {Date} [now=new Date()]
 * @returns {string}
 */
function generateSafeFileName(prefix = 'IUH-GPA-Mo-Phong', extension = 'csv', now = new Date()) {
  // Sanitize prefix: chỉ cho phép chữ cái, chữ số, gạch ngang, gạch dưới
  const cleanPrefix = String(prefix)
    .replace(/[^a-zA-Z0-9_\-]/g, '')
    .substring(0, 32) || 'IUH-GPA-Mo-Phong';

  const year = now.getFullYear();
  const month = String(now.getMonth() + 1).padStart(2, '0');
  const day = String(now.getDate()).padStart(2, '0');

  const cleanExt = String(extension).replace(/[^a-zA-Z0-9]/g, '').toLowerCase() || 'csv';

  return `${cleanPrefix}-${year}-${month}-${day}.${cleanExt}`;
}

class ExportEngine {
  /**
   * Tạo chuỗi CSV từ dữ liệu học kỳ và kịch bản mô phỏng
   *
   * @param {Object} options
   * @param {Array<Object>} options.semesters - Danh sách học kỳ từ derivedData
   * @param {string} [options.scenarioName='Mặc định'] - Tên kịch bản đang active
   * @param {Object} [options.overallSummary] - Tổng kết GPA toàn khóa { original, simulated }
   * @returns {string} - Chuỗi CSV hoàn chỉnh bao gồm UTF-8 BOM
   */
  static generateCSV(options = {}) {
    const { semesters = [], scenarioName = 'Mặc định', overallSummary = null } = options;

    const lines = [];

    // Dòng 1: Disclaimer bắt buộc
    lines.push(escapeCSVField(`# ${EXPORT_DISCLAIMER}`));

    // Dòng 2: Metadata kịch bản và ngày xuất (không chứa PII)
    const exportTime = new Date().toISOString().slice(0, 10);
    lines.push(escapeCSVField(`# Kịch bản: ${scenarioName} | Ngày xuất: ${exportTime}`));

    // Dòng 3: Tổng quan GPA nếu có
    if (overallSummary) {
      const orig4 = overallSummary.original?.gpa4 !== null ? overallSummary.original.gpa4.toFixed(2) : '--';
      const sim4 = overallSummary.simulated?.gpa4 !== null ? overallSummary.simulated.gpa4.toFixed(2) : '--';
      lines.push(escapeCSVField(`# GPA Hệ 4 Gốc: ${orig4} | GPA Hệ 4 Mô phỏng: ${sim4}`));
    }

    // Dòng trống phân cách metadata
    lines.push('');

    // Dòng tiêu đề cột chính thức
    const headers = [
      'Học kỳ',
      'Mã môn',
      'Tên môn',
      'Số tín chỉ',
      'Điểm cuối kỳ gốc',
      'Điểm cuối kỳ mô phỏng',
      'Điểm tổng kết gốc',
      'Điểm tổng kết mô phỏng',
      'Điểm hệ 4 mô phỏng',
      'Điểm chữ mô phỏng',
      'Trạng thái mô phỏng'
    ];
    lines.push(headers.map(escapeCSVField).join(','));

    // Các dòng dữ liệu
    for (const sem of semesters) {
      const semName = sem.semesterName || sem.semesterKey || 'Học kỳ';

      if (!Array.isArray(sem.courses)) continue;

      for (const course of sem.courses) {
        // Tín chỉ
        const credits = course.credits?.status === 'ok' ? course.credits.value : (course.credits?.raw || 0);

        // Điểm cuối kỳ gốc vs mô phỏng
        const origFinal = course.originalFinal !== null && course.originalFinal !== undefined ? course.originalFinal : '';
        const simFinal = course.simulatedFinal !== null && course.simulatedFinal !== undefined ? course.simulatedFinal : origFinal;

        // Điểm tổng kết gốc vs mô phỏng
        const origTotal = course.officialResult?.total10?.status === 'ok'
          ? course.officialResult.total10.value
          : (course.score10 !== null ? course.score10 : '');
        const simTotal = course.score10 !== null && course.score10 !== undefined ? course.score10 : '';

        // Điểm thang 4 & chữ mô phỏng
        const simScore4 = course.score4 !== null && course.score4 !== undefined ? course.score4 : '';
        const simLetter = course.letter || '';

        // Trạng thái đạt/rớt
        const statusText = course.passed === true ? 'ĐẠT' : (course.passed === false ? 'RỚT' : 'CHƯA CÓ ĐIỂM');

        const row = [
          semName,
          course.courseCode || course.id || '',
          course.courseName || '',
          credits,
          origFinal,
          simFinal,
          origTotal,
          simTotal,
          simScore4,
          simLetter,
          statusText
        ];

        lines.push(row.map(escapeCSVField).join(','));
      }
    }

    // Xuất các học kỳ trong kế hoạch tương lai nếu có (Requirement 67 & 68)
    const futureSemesters = (options.futurePlan && Array.isArray(options.futurePlan.semesters))
      ? options.futurePlan.semesters
      : (Array.isArray(semesters) ? semesters.filter(s => s.isFuture) : []);

    if (futureSemesters.length > 0) {
      lines.push('');
      lines.push(escapeCSVField('# KẾ HOẠCH HỌC TẬP TƯƠNG LAI (MÔ PHỎNG – KHÔNG PHẢI BẢNG ĐIỂM CHÍNH THỨC)'));

      for (const fSem of futureSemesters) {
        // Tránh trùng lặp nếu fSem đã được duyệt trong vòng lặp trước
        if (semesters.includes(fSem)) continue;

        const semLabel = (fSem.label || fSem.semesterName || 'Học kỳ mô phỏng') + ' [Mô phỏng tương lai]';
        const courses = fSem.courses || [];

        for (const fc of courses) {
          const credits = fc.credits || 0;
          const origFinal = ''; // Không có điểm gốc vì là tương lai
          const origTotal = '';

          let simFinal = '';
          if (fc.scores && fc.scores.final !== null && fc.scores.final !== undefined) {
            simFinal = fc.scores.final;
          } else if (fc.isPlannedPreset && fc.plannedLetterGradeOverride) {
            simFinal = 'Giả định ' + fc.plannedLetterGradeOverride;
          }

          const simTotal = (fc.score10Raw !== null && fc.score10Raw !== undefined)
            ? fc.score10Raw
            : (typeof fc.plannedScore10Override === 'number' ? fc.plannedScore10Override : '');

          const simScore4 = (fc.score4Raw !== null && fc.score4Raw !== undefined)
            ? fc.score4Raw
            : (typeof fc.plannedGradePointOverride === 'number' ? fc.plannedGradePointOverride : '');

          const simLetter = fc.letter || fc.plannedLetterGradeOverride || '';

          let statusText = 'MÔ PHỎNG TƯƠNG LAI';
          if (fc.isPassed === true || (fc.plannedGradePointOverride && fc.plannedGradePointOverride >= 1.0)) {
            statusText = fc.isPlannedPreset ? 'ĐẠT (Mô phỏng - Giả định)' : 'ĐẠT (Mô phỏng tương lai)';
          } else if (fc.isPassed === false) {
            statusText = 'RỚT (Mô phỏng tương lai)';
          }

          const row = [
            semLabel,
            fc.curriculumCourseCode || fc.code || fc.id || '',
            fc.courseName || '',
            credits,
            origFinal,
            simFinal,
            origTotal,
            simTotal,
            simScore4,
            simLetter,
            statusText
          ];

          lines.push(row.map(escapeCSVField).join(','));
        }
      }
    }

    // Kết hợp bằng CRLF (\r\n) chuẩn cho Windows & Excel
    // Thêm UTF-8 BOM (\uFEFF) để Excel hiển thị đúng tiếng Việt có dấu
    return '\uFEFF' + lines.join('\r\n');
  }

  /**
   * Tạo Blob và kích hoạt download phía client an toàn
   * KHÔNG yêu cầu quyền chrome.downloads
   * Sử dụng URL.createObjectURL và giải phóng ngay bằng URL.revokeObjectURL
   *
   * @param {string} content
   * @param {string} fileName
   * @param {string} [mimeType='text/csv;charset=utf-8;']
   * @param {Document} [doc=document]
   * @returns {boolean} - true nếu thành công
   */
  static triggerDownload(content, fileName, mimeType = 'text/csv;charset=utf-8;', doc = (typeof document !== 'undefined' ? document : null)) {
    if (!doc || !doc.createElement) {
      return false;
    }

    try {
      const blob = new Blob([content], { type: mimeType });
      const url = URL.createObjectURL(blob);

      const a = doc.createElement('a');
      a.style.display = 'none';
      a.href = url;
      a.download = fileName;

      doc.body.appendChild(a);
      a.click();

      // Dọn dẹp DOM và giải phóng memory object URL
      setTimeout(() => {
        if (a.parentElement) {
          a.parentElement.removeChild(a);
        }
        URL.revokeObjectURL(url);
      }, 100);

      return true;
    } catch (e) {
      console.error('[IUH-GPA] EXPORT_DOWNLOAD_FAILED');
      return false;
    }
  }
}

  if (typeof module !== 'undefined' && module.exports) {
    module.exports = {
      ExportEngine,
      sanitizeSpreadsheetCell,
      escapeCSVField,
      generateSafeFileName,
      EXPORT_DISCLAIMER
    };
  }
  if (global) {
    const root = global.IUHGPA || (global.IUHGPA = Object.create(null));
    root.core = root.core || Object.create(null);
    root.core.ExportEngine = ExportEngine;
    root.core.sanitizeSpreadsheetCell = sanitizeSpreadsheetCell;
    root.core.escapeCSVField = escapeCSVField;
    root.core.generateSafeFileName = generateSafeFileName;
    root.core.EXPORT_DISCLAIMER = EXPORT_DISCLAIMER;
    global._IUHExportEngine = {
      ExportEngine,
      sanitizeSpreadsheetCell,
      escapeCSVField,
      generateSafeFileName,
      EXPORT_DISCLAIMER
    };
  }
})(typeof globalThis !== 'undefined' ? globalThis : this);
